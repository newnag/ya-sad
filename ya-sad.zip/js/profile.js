// ช่องวันเกิด
$('#date').flatpickr({
  dateFormat: "d-m-Y",
  minDate: "today",
  disableMobile: "true"
})